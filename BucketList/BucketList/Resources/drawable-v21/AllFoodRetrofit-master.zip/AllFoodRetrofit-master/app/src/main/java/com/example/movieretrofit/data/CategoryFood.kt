package com.example.movieretrofit.data

data class CategoryFood(
    var name: String? = null,
    var results: List<Food>
)