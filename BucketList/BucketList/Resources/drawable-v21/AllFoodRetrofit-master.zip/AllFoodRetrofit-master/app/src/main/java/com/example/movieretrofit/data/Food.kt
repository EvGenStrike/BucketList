package com.example.movieretrofit.data

data class Food(
    var name: String? = null,
    var content: String? = null,
    var image: String? = null
) : java.io.Serializable