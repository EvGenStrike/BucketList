package com.example.movieretrofit.interfaces

interface FoodClickListener {
    fun onFoodClickListener(food: String)
}
